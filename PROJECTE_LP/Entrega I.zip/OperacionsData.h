#pragma once

#include "Data.h"

bool terminiValid(Data& diaOriginal, int nDies, Data& dataActual);

